(function () {
  'use strict';

  const S = globalThis.soroagent;
  const { ext, DEFAULT_SETTINGS, PROVIDER_PRESETS, CLOUD_PROVIDERS } = S;
  const $ = (id) => document.getElementById(id);
  const TEXT_FIELDS = ['baseUrl', 'provider', 'apiKey', 'launcherPosition', 'cloudProvider', 'customBaseUrl', 'researchEngine', 'searxUrl'];
  const NUMBER_FIELDS = ['temperature', 'contextWindow', 'maxPageChars', 'readMoreLimit'];
  const CHECK_FIELDS = ['allowThinking', 'showLauncher', 'trackTime'];

  let saved = { ...DEFAULT_SETTINGS }; // last saved settings, for fields this page doesn't show
  let hiddenSites = [];
  let pendingKeys = {}; // keys typed on this page, not yet saved
  let savedKeys = {}; // provider -> last 4 characters of the saved key (the page never gets the key itself)
  let modelChoice = { local: '', cloud: {} }; // model picked per connection while editing
  let testRun = 0;

  const source = () => document.querySelector('input[name="source"]:checked')?.value || 'local';
  const currentModelKey = () => (source() === 'cloud' ? $('cloudProvider').value : 'local');

  function rememberModel() {
    const value = $('model').value;
    if (currentModelKey() === 'local') modelChoice.local = value;
    else modelChoice.cloud[currentModelKey()] = value;
  }

  function chosenModel() {
    return currentModelKey() === 'local' ? modelChoice.local : modelChoice.cloud[currentModelKey()] || '';
  }

  // ---------------------------------------------------------------------------
  // Prompts: the system prompt per prompt set, edited here and optimized by the model.
  // ---------------------------------------------------------------------------

  const promptSets = S.listPromptSets().sort((a, b) => (a.id === 'default' ? -1 : b.id === 'default' ? 1 : a.label.localeCompare(b.label)));
  let customPrompts = {};
  let promptSiteId = 'default';
  let undoText = null;
  const builtInPrompt = (id) => (promptSets.find((p) => p.id === id) || promptSets[0]).persona;

  // Keeps the text being edited in customPrompts (or drops it when it's the built-in one).
  function keepPromptEdit() {
    const text = $('promptText').value.trim();
    if (!text || text === builtInPrompt(promptSiteId).trim()) delete customPrompts[promptSiteId];
    else customPrompts[promptSiteId] = text;
  }

  function showPrompt(id) {
    promptSiteId = id;
    const set = promptSets.find((p) => p.id === id) || promptSets[0];
    $('promptSite').value = set.id;
    $('promptText').value = customPrompts[id] || builtInPrompt(id);
    $('promptHosts').textContent = set.id === 'default' ? 'Used on every website without its own prompt below.' : `Used on ${set.hosts.join(', ')}.`;
    $('promptBadge').hidden = !customPrompts[id];
    $('undoPrompt').hidden = true;
    undoText = null;
    $('promptStatus').textContent = '';
  }

  function fillPrompts(settings) {
    customPrompts = { ...(settings.customPrompts || {}) };
    $('promptSite').replaceChildren(...promptSets.map((p) => Object.assign(document.createElement('option'), {
      value: p.id,
      textContent: p.id === 'default' ? 'All websites (default)' : `${p.label} · ${p.hosts.slice(0, 2).join(', ')}${p.hosts.length > 2 ? '…' : ''}`,
    })));
    showPrompt(promptSiteId);
  }

  $('promptSite').addEventListener('change', () => {
    keepPromptEdit();
    showPrompt($('promptSite').value);
  });
  $('promptText').addEventListener('input', () => {
    keepPromptEdit();
    $('promptBadge').hidden = !customPrompts[promptSiteId];
  });
  $('resetPrompt').addEventListener('click', () => {
    undoText = $('promptText').value;
    delete customPrompts[promptSiteId];
    $('promptText').value = builtInPrompt(promptSiteId);
    $('promptBadge').hidden = true;
    $('undoPrompt').hidden = false;
    $('promptStatus').textContent = 'Back to the built-in prompt. Save to keep it.';
  });
  $('undoPrompt').addEventListener('click', () => {
    if (undoText === null) return;
    $('promptText').value = undoText;
    keepPromptEdit();
    $('promptBadge').hidden = !customPrompts[promptSiteId];
    $('undoPrompt').hidden = true;
    $('promptStatus').textContent = '';
  });

  $('optimizePrompt').addEventListener('click', async () => {
    const set = promptSets.find((p) => p.id === promptSiteId);
    const current = $('promptText').value.trim() || builtInPrompt(promptSiteId);
    const button = $('optimizePrompt');
    button.disabled = true;
    $('promptStatus').className = 'muted working';
    $('promptStatus').textContent = 'Your model is rewriting the prompt…';
    try {
      const reply = await S.askModel([
        {
          role: 'system',
          content: 'You are an expert prompt engineer. You improve system prompts for soroagent, a browser assistant that summarizes web pages and answers questions about them. Reply with the improved system prompt only: plain text, no preamble, no quotes, no headings.',
        },
        {
          role: 'user',
          content: `Website: ${set.id === 'default' ? 'any website' : `${set.label} (${set.hosts.join(', ')})`}

Current system prompt:
<prompt>
${current}
</prompt>

Rewrite it to get better results on this website. Keep the intent and every rule it states. Make it specific to how content on this site works, and clear about accuracy, what to prioritize, tone and format (Markdown). Keep it under 120 words, in the second person, starting with "You are soroagent".`,
        },
      ]);
      const improved = S.stripThinking(reply).replace(/^```\w*\n?|```$/g, '').replace(/^<prompt>|<\/prompt>$/g, '').replace(/^["“]|["”]$/g, '').trim();
      if (!improved) throw new Error('The model returned an empty prompt.');
      undoText = $('promptText').value;
      $('promptText').value = improved;
      keepPromptEdit();
      $('promptBadge').hidden = !customPrompts[promptSiteId];
      $('undoPrompt').hidden = false;
      $('promptStatus').className = 'muted';
      $('promptStatus').textContent = 'Optimized. Review it, then Save.';
    } catch (err) {
      $('promptStatus').className = 'muted';
      $('promptStatus').textContent = `Couldn't optimize: ${err.message}${err.hint ? ` ${err.hint}` : ''}`;
    } finally {
      button.disabled = false;
    }
  });

  function readForm() {
    rememberModel();
    keepPromptEdit();
    const values = { ...saved, source: source(), hiddenSites, model: modelChoice.local, cloudModels: { ...modelChoice.cloud } };
    for (const id of TEXT_FIELDS) values[id] = $(id).value.trim();
    for (const id of NUMBER_FIELDS) {
      const n = Number($(id).value);
      values[id] = Number.isFinite(n) && $(id).value !== '' ? n : DEFAULT_SETTINGS[id];
    }
    for (const id of CHECK_FIELDS) values[id] = $(id).checked;
    values.baseUrl = values.baseUrl || DEFAULT_SETTINGS.baseUrl;
    values.customPrompts = { ...customPrompts };
    return values;
  }

  function fillForm(settings) {
    saved = settings;
    for (const id of [...TEXT_FIELDS, ...NUMBER_FIELDS]) $(id).value = settings[id];
    for (const id of CHECK_FIELDS) $(id).checked = Boolean(settings[id]);
    document.querySelector(`input[name="source"][value="${settings.source === 'cloud' ? 'cloud' : 'local'}"]`).checked = true;
    modelChoice = { local: settings.model || '', cloud: { ...(settings.cloudModels || {}) } };
    hiddenSites = [...(settings.hiddenSites || [])];
    renderSites();
    renderPlacements();
    fillPrompts(settings);
    showSource();
  }

  // Shows the fields for the selected source/provider and resets the model list.
  function showSource() {
    const cloud = source() === 'cloud';
    $('localFields').hidden = cloud;
    $('cloudFields').hidden = !cloud;
    const provider = S.cloudProvider($('cloudProvider').value);
    $('customBaseUrlField').hidden = provider.id !== 'custom';
    showKeyField();
    $('keyLink').hidden = !provider.keyUrl;
    if (provider.keyUrl) $('keyLink').href = provider.keyUrl;
    $('cloudName').textContent = provider.id === 'custom' ? 'that API' : provider.label;
    $('modelHint').textContent = cloud
      ? 'Larger models give better summaries and filtering; smaller ones are faster and cheaper.'
      : 'Smaller models (3–8B) answer faster; larger ones summarize and filter better.';
    setModelOptions([], chosenModel());
    $('result').hidden = true;
    $('recs').hidden = true;
  }

  function showKeyField() {
    const id = $('cloudProvider').value;
    const provider = S.cloudProvider(id);
    $('cloudKey').value = pendingKeys[id] || '';
    $('cloudKey').placeholder = savedKeys[id]
      ? `Saved key ending in …${savedKeys[id]} — paste a new key to replace it`
      : provider.keyPlaceholder || 'API key';
    $('removeKey').hidden = !savedKeys[id];
  }

  const hasKey = (id) => Boolean(pendingKeys[id] || savedKeys[id]);

  function setModelOptions(models, selected, suggested = '') {
    const select = $('model');
    const ids = models.map((m) => m.id);
    if (selected && !ids.includes(selected)) ids.unshift(selected);
    select.replaceChildren(new Option(suggested ? `Recommended (${suggested})` : 'Recommended', ''));
    for (const id of ids) {
      const info = models.find((m) => m.id === id);
      const label = info && info.name && info.name !== id ? `${info.name} (${id})` : id;
      select.append(new Option(info && info.size ? `${label} · ${info.size}` : label, id));
    }
    select.value = selected || '';
  }

  function renderSites() {
    const box = $('sites');
    box.replaceChildren();
    if (!hiddenSites.length) {
      box.append(Object.assign(document.createElement('span'), { className: 'muted', textContent: 'None' }));
      return;
    }
    for (const site of hiddenSites) {
      const chip = document.createElement('span');
      chip.className = 'site';
      chip.textContent = site;
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.textContent = '×';
      remove.setAttribute('aria-label', `Show the button on ${site} again`);
      remove.addEventListener('click', () => {
        hiddenSites = hiddenSites.filter((s) => s !== site);
        renderSites();
      });
      chip.append(remove);
      box.append(chip);
    }
  }

  function renderPlacements() {
    const count = Object.keys(saved.launcherPlacements || {}).length;
    $('placementsRow').hidden = !count;
    $('placementsText').textContent = `You've moved the button on ${count} site${count === 1 ? '' : 's'}.`;
  }

  // Local models only: the background ranks installed models for soroagent's tasks.
  function renderRecommendations(res) {
    const box = $('recs');
    box.replaceChildren();
    const recs = (res && !res.cloud && res.recommended) || [];
    box.hidden = !recs.length && !(res && res.pullSuggestion);
    if (box.hidden) return;
    const make = (tag, props) => Object.assign(document.createElement(tag), props);
    box.append(make('div', { className: 'recs-title', textContent: 'Best installed models for soroagent' }));
    for (const rec of recs) {
      const text = make('div', {});
      text.append(make('b', { textContent: `${rec.label}: ${rec.id}` }), make('small', { textContent: rec.reason }));
      const use = make('button', { type: 'button', className: 'btn small', textContent: $('model').value === rec.id ? 'Selected' : 'Use' });
      use.addEventListener('click', () => {
        $('model').value = rec.id;
        rememberModel();
        renderRecommendations(res);
      });
      const row = make('div', { className: 'rec' });
      row.append(text, use);
      box.append(row);
    }
    if (res.pullSuggestion) {
      box.append(make('small', {
        className: 'muted',
        textContent: `${recs.length ? 'For better results' : "None of your models fit well"}, try ${res.pullSuggestion.reason}: ${res.pullSuggestion.command}`,
      }));
    }
    box.append(make('small', { className: 'muted', textContent: 'Ranked by model family, size and speed. Larger models need more memory.' }));
  }

  function showResult(kind, title, detail) {
    $('result').hidden = false;
    $('resultDot').className = `dot ${kind}`;
    const text = $('resultText');
    text.replaceChildren(Object.assign(document.createElement('div'), { textContent: title }));
    if (detail) text.append(Object.assign(document.createElement('pre'), { textContent: detail }));
  }

  async function testConnection() {
    const form = readForm();
    const run = ++testRun;
    const connection = S.resolveConnection(form);
    showResult('connecting', `Connecting to ${connection.cloud ? connection.label : form.baseUrl}…`);
    $('test').disabled = true;
    try {
      // Typed keys are tested before saving; otherwise the background uses the saved, encrypted key.
      const res = await ext.runtime.sendMessage({ type: 'llm:status', overrides: { settings: form, apiKeys: { ...pendingKeys } } });
      if (run !== testRun) return; // a newer test started (source or provider changed)
      if (!res || res.ok === false) {
        showResult('offline', (res && res.error) || 'Connection failed.', res && res.hint);
        return;
      }
      const where = res.cloud ? res.providerLabel : `${res.api === 'ollama' ? 'Ollama' : 'OpenAI-compatible API'} at ${res.baseUrl}`;
      const count = res.models.length;
      showResult(
        'ready',
        `Connected to ${where} — ${count} chat model${count === 1 ? '' : 's'} available.`,
        count ? '' : res.cloud ? 'This key has no chat models available.' : 'Download a model first, for example: ollama pull llama3.2'
      );
      setModelOptions(res.models, chosenModel(), res.model);
      renderRecommendations(res);
    } finally {
      if (run === testRun) $('test').disabled = false;
    }
  }

  for (const preset of PROVIDER_PRESETS) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'btn small';
    button.textContent = preset.label;
    button.addEventListener('click', () => {
      $('baseUrl').value = preset.baseUrl;
      $('provider').value = preset.provider;
      testConnection();
    });
    $('presets').append(button);
  }

  for (const provider of CLOUD_PROVIDERS) $('cloudProvider').append(new Option(provider.label, provider.id));

  // Each source/provider keeps its own model choice; rememberModel records it as it changes.
  $('model').addEventListener('change', rememberModel);
  for (const radio of document.querySelectorAll('input[name="source"]')) {
    radio.addEventListener('change', () => {
      showSource();
      if (source() === 'local' || hasKey($('cloudProvider').value)) testConnection();
    });
  }
  $('cloudProvider').addEventListener('change', () => {
    showSource();
    if (hasKey($('cloudProvider').value)) testConnection();
  });

  $('cloudKey').addEventListener('input', () => {
    const value = $('cloudKey').value.trim();
    if (value) pendingKeys[$('cloudProvider').value] = value;
    else delete pendingKeys[$('cloudProvider').value];
  });
  $('cloudKey').addEventListener('change', () => {
    if ($('cloudKey').value.trim()) testConnection();
  });
  $('toggleKey').addEventListener('click', () => {
    const show = $('cloudKey').type === 'password';
    $('cloudKey').type = show ? 'text' : 'password';
    $('toggleKey').textContent = show ? 'Hide' : 'Show';
  });

  $('removeKey').addEventListener('click', async () => {
    const id = $('cloudProvider').value;
    if (!confirm(`Remove the saved ${S.cloudProvider(id).label} API key from this browser?`)) return;
    const res = await ext.runtime.sendMessage({ type: 'keys:remove', provider: id });
    if (res && res.ok) savedKeys = res.keys;
    delete pendingKeys[id];
    showKeyField();
    $('result').hidden = true;
  });

  $('resetPlacements').addEventListener('click', async () => {
    saved = await S.saveSettings({ launcherPlacements: {} });
    renderPlacements();
  });

  // Backup & restore (snippets, summary history, settings; never API keys).
  $('backup').addEventListener('click', async () => {
    const backup = S.buildBackup(await ext.storage.local.get(null), ext.runtime.getManifest().version);
    const url = URL.createObjectURL(new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' }));
    Object.assign(document.createElement('a'), { href: url, download: `soroagent-backup-${new Date().toISOString().slice(0, 10)}.json` }).click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    $('backupStatus').textContent = `Backed up ${backup.snippets.length} snippets and ${backup.summaries.length} summaries.`;
  });
  $('restore').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (!file) return;
    try {
      const backup = JSON.parse(await file.text());
      const includeSettings = confirm('Also restore the settings from this backup? (Cancel keeps your current settings.)');
      const { updates, counts } = S.planRestore(backup, await ext.storage.local.get(null), { includeSettings });
      await ext.storage.local.set(updates);
      await S.migrate(ext.storage.local);
      $('backupStatus').textContent = `Restored ${counts.snippets} snippets and ${counts.summaries} summaries${counts.settings ? ' and settings' : ''}. Items you already had were kept.`;
      if (counts.settings) fillForm(await S.getSettings());
    } catch (err) {
      $('backupStatus').textContent = `Couldn't restore: ${err.message}`;
    }
  });

  $('test').addEventListener('click', testConnection);

  $('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    if (Object.keys(pendingKeys).length) {
      const res = await ext.runtime.sendMessage({ type: 'keys:set', keys: pendingKeys });
      if (!res || !res.ok) {
        $('saved').textContent = `Couldn't save the API key: ${(res && res.error) || 'unknown error'}`;
        return;
      }
      savedKeys = res.keys;
      pendingKeys = {};
      showKeyField();
    }
    const form = readForm();
    // Choosing a model here means the panel never needs to suggest one.
    saved = await S.saveSettings({ ...form, modelTipSeen: Boolean(saved.modelTipSeen || chosenModel()) });
    $('saved').textContent = 'Saved.';
    setTimeout(() => ($('saved').textContent = ''), 2500);
  });

  Promise.all([S.getSettings(), ext.runtime.sendMessage({ type: 'keys:describe' })]).then(([settings, res]) => {
    savedKeys = (res && res.keys) || {};
    const keys = savedKeys;
    fillForm(settings);
    if (settings.source !== 'cloud' || keys[settings.cloudProvider]) testConnection();
  });
})();
