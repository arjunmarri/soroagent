// Styles for the assistant. They live inside a shadow root, so pages can't restyle the
// assistant and the assistant can't leak styles into pages.
(function (root) {
  'use strict';

  const soroagent = (root.soroagent = root.soroagent || {});

  soroagent.ASSISTANT_CSS = `
:host {
  all: initial;
  /* Brand: the owl's green and orange. Text-safe shades are used for words, the bright ones for
     marks, rings and small highlights. */
  --brand: #34D399;
  --spark: #F59E0B;
  --bg: #ffffff;
  --bg-soft: #f6f7f7;
  --bg-hover: #eef0ef;
  --fg: #111613;
  --fg-muted: #5f6763;
  --border: #e3e7e5;
  --accent: #047857;
  --accent-strong: #065f46;
  --accent-fg: #ffffff;
  --accent-soft: #ecfdf5;
  --spark-fg: #b45309;
  --spark-soft: #fff7ed;
  --ok: #059669;
  --warn: #d97706;
  --err: #dc2626;
  --shadow: 0 24px 60px rgba(10, 30, 20, 0.18), 0 2px 8px rgba(10, 30, 20, 0.08);
  --owl-bg: #FFFFFF;
  --owl-border: #E3E7E5;
  font: 14px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  color: var(--fg);
}
@media (prefers-color-scheme: dark) {
  :host {
    --spark: #FBBF24;
    --bg: #151716;
    --bg-soft: #1d201f;
    --bg-hover: #262a28;
    --fg: #eef2f0;
    --fg-muted: #9aa39f;
    --border: #2e3330;
    --accent: #34d399;
    --accent-strong: #6ee7b7;
    --accent-fg: #03261a;
    --accent-soft: #11291f;
    --spark-fg: #fbbf24;
    --spark-soft: #2a2213;
    --ok: #34d399;
    --shadow: 0 24px 60px rgba(0, 0, 0, 0.6), 0 2px 8px rgba(0, 0, 0, 0.35);
    --owl-bg: #111312;
    --owl-border: #2A2E2C;
  }
}
*, *::before, *::after { box-sizing: border-box; }
[hidden] { display: none !important; }
button, select, textarea { font: inherit; color: inherit; }
button { cursor: pointer; }
button:disabled { cursor: not-allowed; opacity: 0.5; }
:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }
svg { width: 18px; height: 18px; flex: none; }

.launcher {
  position: fixed; right: 16px; bottom: 20px; z-index: 2147483647;
  width: 50px; height: 50px; border-radius: 50%; padding: 0; overflow: hidden;
  display: grid; place-items: center; touch-action: none;
  /* Follows the browser theme: white in light mode, near-black in dark mode. */
  background: var(--owl-bg); border: 1px solid var(--owl-border);
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.18), 0 1px 3px rgba(0, 0, 0, 0.1);
  transition: transform 0.15s ease, box-shadow 0.15s ease, top 0.25s ease, left 0.25s ease, right 0.25s ease;
}
.launcher:hover { transform: translateY(-2px); box-shadow: 0 0 0 3px color-mix(in srgb, var(--brand) 35%, transparent), 0 10px 24px rgba(0, 0, 0, 0.22); }
.launcher.open { box-shadow: 0 0 0 2px var(--brand), 0 8px 22px rgba(0, 0, 0, 0.2); }
.launcher:focus-visible { outline: none; box-shadow: 0 0 0 3px var(--brand), 0 8px 22px rgba(0, 0, 0, 0.2); }
.launcher.danger { border-color: #ef4444; box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.9), 0 0 22px 6px rgba(239, 68, 68, 0.5); animation: danger-glow 1.8s ease-in-out infinite; }
.launcher.danger:hover, .launcher.danger.open { box-shadow: 0 0 0 3px #ef4444, 0 0 26px 8px rgba(239, 68, 68, 0.6); }
@keyframes danger-glow { 50% { box-shadow: 0 0 0 3px #ef4444, 0 0 32px 12px rgba(239, 68, 68, 0.7); } }
.launcher.dragging { transition: none; cursor: grabbing; transform: scale(1.06); }
.launcher.busy::after {
  content: ""; position: absolute; inset: -1px; border-radius: 50%;
  border: 2px solid transparent; border-top-color: var(--brand); border-right-color: var(--spark); animation: spin 0.9s linear infinite;
}

/* The owl. Its eye glints follow the mouse (--px/--py in -1..1, set by launcher.js) or drift on
   their own; it blinks now and then, looks around while working, perks up when the panel opens,
   flaps its wings while carried or flying, and hops when it lands. */
.owl { width: 100%; height: 100%; display: block; overflow: visible; }
.owl .bird, .owl .eyes, .owl .glint, .owl .wing { transform-box: fill-box; transform-origin: center; }
.owl .eyes { animation: blink 7s infinite; }
.owl .glint { transform: translate(calc(var(--px, 0) * 4px), calc(var(--py, 0) * 4px)); animation: watch 11s ease-in-out infinite; transition: transform 0.18s ease-out; }
.launcher.tracking .owl .glint { animation: none; }
.launcher:hover .owl .eyes { animation: none; transform: scale(1.05); transition: transform 0.2s ease; }
.launcher.open .owl { animation: perk 0.5s ease; }
.launcher.open .owl .glint { animation: none; transform: translate(calc(var(--px, 0) * 4px), calc(var(--py, 0) * 4px)) scale(1.3); }
.launcher.busy .owl .glint { animation: scan 1.4s ease-in-out infinite; }
.owl .wing-l { transform-origin: 85% 8%; }
.owl .wing-r { transform-origin: 15% 8%; }
.launcher.carried .owl .wing-l, .launcher.flying .owl .wing-l { animation: flap-l 0.2s ease-in-out infinite alternate; }
.launcher.carried .owl .wing-r, .launcher.flying .owl .wing-r { animation: flap-r 0.2s ease-in-out infinite alternate; }
.launcher.carried { cursor: grabbing; transform: scale(1.08); box-shadow: 0 16px 30px rgba(0, 0, 0, 0.3); }
.launcher.flying { transition: none !important; transform: rotate(var(--tilt, 0deg)) scale(1.04); }
.launcher.landing { animation: land 0.42s ease-out; }

.panel {
  position: fixed; right: 16px; bottom: 80px; z-index: 2147483647;
  width: min(var(--panel-w, 400px), calc(100vw - 24px)); height: min(600px, calc(100vh - 100px));
  transition: width 0.18s ease, height 0.18s ease;
  display: flex; flex-direction: column;
  background: var(--bg); border: 1px solid var(--border); border-radius: 16px;
  box-shadow: var(--shadow); overflow: hidden;
  animation: pop 0.16s ease-out;
}
/* A thin green-to-orange line along the top: the owl's colours, quietly. */
.panel::before { content: ""; position: absolute; inset: 0 0 auto 0; height: 2px; z-index: 3; background: linear-gradient(90deg, var(--brand), var(--spark)); }

header {
  position: relative; display: flex; align-items: center; gap: 8px;
  padding: 12px 10px 10px 14px; border-bottom: 1px solid var(--border);
}
.brand { display: flex; align-items: center; gap: 8px; flex: none; }
.wordmark { font-size: 15px; font-weight: 700; letter-spacing: -0.03em; color: var(--fg); }
.wordmark span { color: var(--accent); }
.brand-mark {
  width: 26px; height: 26px; border-radius: 8px; display: grid; place-items: center; overflow: hidden;
  background: var(--owl-bg); border: 1px solid var(--owl-border);
}
.brand-mark .owl .eyes, .brand-mark .owl .glint { animation: none; }
.status {
  margin-left: auto; min-width: 0; display: flex; align-items: center; gap: 6px;
  padding: 3px 4px 3px 9px; border-radius: 999px; background: var(--bg-soft);
}
.dot { width: 8px; height: 8px; border-radius: 50%; background: var(--fg-muted); flex: none; }
.dot.ready { background: var(--ok); }
.dot.connecting { background: var(--warn); animation: pulse 1s ease-in-out infinite; }
.dot.offline { background: var(--err); }
.status-text { font-size: 12px; color: var(--fg-muted); white-space: nowrap; }
.where {
  font-size: 11px; font-weight: 600; color: var(--spark-fg); background: var(--spark-soft);
  padding: 1px 7px; border-radius: 999px; white-space: nowrap;
}
.model {
  max-width: 150px; min-width: 0; border: none; background: transparent; font-size: 12px;
  padding: 2px 2px; text-overflow: ellipsis; border-radius: 6px;
}
.model:hover { background: var(--bg-hover); }
.icon-btn {
  width: 30px; height: 30px; border-radius: 8px; border: none; background: transparent;
  display: grid; place-items: center; color: var(--fg-muted); flex: none;
}
.icon-btn:hover { background: var(--bg-hover); color: var(--fg); }
.panel.resizing { transition: none; user-select: none; }

/* Resize handles on the panel's free edges (set by launcher.js as data-edge-x / data-edge-y) */
.resize { position: absolute; z-index: 4; touch-action: none; outline: none; }
.resize-x { top: 14px; bottom: 14px; width: 8px; cursor: ew-resize; }
.resize-y { left: 14px; right: 14px; height: 8px; cursor: ns-resize; }
.resize-xy { width: 16px; height: 16px; }
.panel[data-edge-x="left"] .resize-x { left: -3px; }
.panel[data-edge-x="right"] .resize-x { right: -3px; }
.panel[data-edge-x=""] .resize-x, .panel[data-edge-x=""] .resize-xy { display: none; }
.panel[data-edge-y="top"] .resize-y { top: -3px; }
.panel[data-edge-y="bottom"] .resize-y { bottom: -3px; }
.panel[data-edge-y="top"][data-edge-x="left"] .resize-xy { top: -3px; left: -3px; cursor: nwse-resize; }
.panel[data-edge-y="top"][data-edge-x="right"] .resize-xy { top: -3px; right: -3px; cursor: nesw-resize; }
.panel[data-edge-y="bottom"][data-edge-x="left"] .resize-xy { bottom: -3px; left: -3px; cursor: nesw-resize; }
.panel[data-edge-y="bottom"][data-edge-x="right"] .resize-xy { bottom: -3px; right: -3px; cursor: nwse-resize; }
/* A soft green line shows the edge you're about to drag */
.resize-x::after, .resize-y::after { content: ""; position: absolute; border-radius: 2px; background: var(--brand); opacity: 0; transition: opacity .12s ease; }
.resize-x::after { top: 30%; bottom: 30%; left: 3px; width: 2px; }
.resize-y::after { left: 30%; right: 30%; top: 3px; height: 2px; }
.resize:hover::after, .resize:focus-visible::after, .panel.resizing .resize::after { opacity: 0.9; }
.resize-xy::after { content: ""; position: absolute; inset: 4px; border-radius: 50%; background: var(--spark); opacity: 0; transition: opacity .12s ease; }
.resize-xy:hover::after, .resize-xy:focus-visible::after { opacity: 0.9; }
.status { overflow: hidden; }

/* Snippets saved from this page */
.page-snips { display: grid; gap: 6px; margin-top: 8px; }
.page-snip { display: grid; grid-template-columns: auto 1fr; gap: 2px 10px; align-items: center; text-align: left; width: 100%; padding: 8px 10px; border: 1px solid var(--border); border-radius: 10px; background: var(--bg); color: var(--fg); font: inherit; cursor: pointer; }
.page-snip:hover { border-color: var(--accent); }
.page-snip img { grid-row: span 2; width: 56px; height: 36px; object-fit: cover; object-position: top; border-radius: 5px; }
.page-snip .snip-title { font-weight: 600; font-size: 13px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.page-snip .snip-meta { grid-column: 2; font-size: 11.5px; color: var(--fg-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.page-snip .snip-kind { grid-row: span 2; font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .04em; padding: 2px 6px; border-radius: 999px; background: var(--accent-soft); color: var(--accent); }

.menu {
  position: absolute; top: 44px; right: 10px; z-index: 2; min-width: 210px; padding: 5px;
  background: var(--bg); border: 1px solid var(--border); border-radius: 10px; box-shadow: var(--shadow);
}
.menu button {
  display: block; width: 100%; text-align: left; border: none; background: none;
  padding: 7px 10px; border-radius: 6px;
}
.menu button:hover { background: var(--bg-soft); }

.actions { display: flex; flex-wrap: wrap; gap: 5px; padding: 9px 12px; border-bottom: 1px solid var(--border); }
.chip {
  display: inline-flex; align-items: center; gap: 5px; height: 29px; padding: 0 10px;
  border: 1px solid var(--border); border-radius: 999px; background: var(--bg); font-size: 12px; font-weight: 550;
  transition: background 0.12s ease, border-color 0.12s ease, color 0.12s ease;
}
.chip svg { width: 14px; height: 14px; color: var(--accent); }
.chip:hover:not(:disabled) { background: var(--accent-soft); border-color: color-mix(in srgb, var(--accent) 50%, var(--border)); }
.chip.active { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
.chip.active svg { color: var(--spark); }
.chip.spark svg { color: var(--spark); }
.chip.spark { border-color: color-mix(in srgb, var(--spark) 45%, var(--border)); }
.chip.spark:hover:not(:disabled) { background: var(--spark-soft); border-color: var(--spark); }

/* Home: the opening screen over the conversation, which stays underneath */
.thread.home > :not(.empty) { display: none; }
.back-to-chat { margin-top: 10px; border: none; background: none; color: var(--accent); font-size: 12px; font-weight: 600; padding: 4px 8px; border-radius: 8px; }
.back-to-chat:hover { background: var(--accent-soft); }
.suggest button.wish { border-color: color-mix(in srgb, var(--spark) 50%, var(--border)); background: var(--spark-soft); font-weight: 600; }
.suggest button.wish::before { content: "♡"; color: var(--spark); }
.suggest button.wish:hover { border-color: var(--spark); }
.shutter { position: fixed; inset: 0; z-index: 2147483647; background: #fff; pointer-events: none; animation: shutter .45s ease-out forwards; }
@keyframes shutter { from { opacity: .55; } to { opacity: 0; } }
@media (prefers-reduced-motion: reduce) { .shutter { display: none; } }
/* Dark mode inverts the whole page; flip soroagent's own UI back so it looks as usual. */
:host([data-dark]) .launcher, :host([data-dark]) .panel, :host([data-dark]) .shutter { filter: invert(1) hue-rotate(180deg); }
.sliders { display: grid; gap: 8px; margin: 10px 0 4px; }
.sliders label { display: grid; grid-template-columns: 112px 1fr 44px; align-items: center; gap: 10px; font-size: 13px; }
.sliders input[type="range"] { width: 100%; accent-color: var(--accent); }
.sliders output { text-align: right; color: var(--fg-muted); font-variant-numeric: tabular-nums; }

.thread { flex: 1; overflow-y: auto; padding: 14px; display: flex; flex-direction: column; gap: 12px; }
.empty { margin: auto 0; display: flex; flex-direction: column; align-items: center; gap: 6px; color: var(--fg-muted); font-size: 13px; text-align: center; padding: 0 12px; }
.empty-mark { width: 52px; height: 52px; border-radius: 16px; overflow: hidden; border: 1px solid var(--owl-border); background: var(--owl-bg); margin-bottom: 6px; }
.empty-mark .owl .glint { animation: none; }
.empty strong { color: var(--fg); font-size: 16px; font-weight: 650; letter-spacing: -0.015em; }
.empty-note { max-width: 300px; }
.quip { margin: 0 0 4px; padding: 6px 12px; max-width: 300px; border-radius: 12px 12px 12px 4px; background: var(--spark-soft); color: var(--fg); font-size: 12.5px; font-style: italic; line-height: 1.45; }
.suggest { display: grid; gap: 6px; width: 100%; max-width: 300px; margin-top: 12px; }
.suggest button {
  text-align: left; padding: 8px 12px; border: 1px solid var(--border); border-radius: 10px; background: var(--bg);
  color: var(--fg); font-size: 12.5px; transition: border-color 0.12s ease, background 0.12s ease;
}
.suggest button::before { content: "→"; color: var(--spark); margin-right: 8px; }
.suggest button:hover { border-color: var(--accent); background: var(--accent-soft); }
.empty-hint { margin: 10px 0 0; font-size: 12px; }

.msg { max-width: 100%; overflow-wrap: anywhere; }
.msg.user {
  align-self: flex-end; max-width: 85%; padding: 8px 12px; border-radius: 14px 14px 4px 14px;
  background: var(--accent); color: var(--accent-fg); white-space: pre-wrap;
}
.msg.assistant { align-self: stretch; }
.msg.assistant > :first-child { margin-top: 0; }
.msg.assistant > :last-child { margin-bottom: 0; }
.msg p, .msg ul, .msg ol, .msg pre { margin: 0 0 8px; }
.msg ul, .msg ol { padding-left: 20px; }
.msg li { margin: 2px 0; }
.msg h3, .msg h4, .msg h5, .msg h6 { margin: 12px 0 4px; font-size: 14px; }
.msg code { font: 12.5px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; background: var(--bg-soft); padding: 1px 4px; border-radius: 4px; }
.msg pre { background: var(--bg-soft); padding: 10px; border-radius: 8px; overflow-x: auto; }
.msg pre code { background: none; padding: 0; }
.msg a { color: var(--accent); }
.typing { color: var(--fg-muted); font-size: 13px; display: inline-flex; gap: 6px; align-items: center; }
.typing::before {
  content: ""; width: 12px; height: 12px; border-radius: 50%;
  border: 2px solid var(--border); border-top-color: var(--brand); border-right-color: var(--spark); animation: spin 0.8s linear infinite;
}

.card { border: 1px solid var(--border); border-radius: 12px; padding: 10px 12px; background: var(--bg-soft); font-size: 13px; }
.card.error { border-color: color-mix(in srgb, var(--err) 45%, var(--border)); }
.card-title { font-weight: 600; display: flex; align-items: center; gap: 6px; margin-bottom: 2px; }
.card-title svg { width: 16px; height: 16px; }
.card.error .card-title svg { color: var(--err); }
.card.ok .card-title svg { color: var(--ok); }
.card p { margin: 4px 0 0; color: var(--fg-muted); }
.card pre { margin: 8px 0 0; white-space: pre-wrap; font: 12px ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; color: var(--fg); }
.card-actions { display: flex; gap: 6px; margin-top: 8px; flex-wrap: wrap; }
.card-actions button { border: 1px solid var(--border); background: var(--bg); border-radius: 8px; padding: 3px 9px; font-size: 11.5px; }

/* Research: pick a topic first */
.topics-status { margin: 4px 0 8px; }
.topics { display: flex; flex-wrap: wrap; gap: 5px; }
.topic { border: 1px solid var(--border); background: var(--bg); border-radius: 999px; padding: 4px 10px; font-size: 11.5px; text-align: left; }
.topic:hover { border-color: var(--accent); background: var(--accent-soft); }
.topic.all { border-style: dashed; color: var(--fg-muted); }
.topic-own { display: flex; gap: 6px; margin-top: 8px; }
.topic-own input { flex: 1; min-width: 0; padding: 5px 9px; border: 1px solid var(--border); border-radius: 8px; background: var(--bg); color: var(--fg); font: inherit; font-size: 12px; outline: none; }
.topic-own input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-soft); }
.topic-own .primary, .card-actions .primary { background: var(--accent); border: 1px solid var(--accent); color: var(--accent-fg); border-radius: 8px; padding: 4px 10px; font-size: 11.5px; font-weight: 600; }
.card-actions button:hover { border-color: var(--accent); }
.tags { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 6px; }
.tag { font-size: 11.5px; padding: 1px 8px; border-radius: 999px; background: var(--accent-soft); color: var(--accent); }
/* Next steps under the latest answer: one compact row, redrawn in place */
.next-steps { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 6px 10px; padding: 6px 8px 6px 10px; border: 1px solid var(--border); border-radius: 10px; font-size: 12px; color: var(--fg-muted); }
.next-status { display: flex; align-items: center; gap: 6px; min-width: 0; flex-wrap: wrap; }
.next-check { color: var(--ok); font-weight: 700; }
.next-note::before { content: "·"; margin-right: 6px; }
.next-status .link { border: none; background: none; padding: 0; color: var(--accent); font-size: 12px; font-weight: 600; }
.next-status .link:hover { text-decoration: underline; }
.next-actions { display: flex; align-items: center; gap: 5px; margin-left: auto; }
.next-actions button { border: 1px solid var(--border); background: var(--bg); border-radius: 8px; padding: 3px 9px; font-size: 11.5px; font-weight: 550; }
.next-actions button:hover { border-color: var(--accent); }
.next-actions .primary { background: var(--accent); border-color: var(--accent); color: var(--accent-fg); }
.next-actions .primary:hover { background: var(--accent-strong); }
.next-actions .dismiss { border: none; background: none; color: var(--fg-muted); font-size: 15px; line-height: 1; padding: 2px 5px; }
.next-actions .dismiss:hover { color: var(--fg); background: var(--bg-hover); }
/* Safety warning above the conversation */
.safety { margin: 10px 12px 0; padding: 10px 12px; border-radius: 12px; border: 1px solid; font-size: 12.5px; }
.safety.danger { border-color: color-mix(in srgb, var(--err) 55%, var(--border)); background: color-mix(in srgb, var(--err) 9%, var(--bg)); }
.safety.caution { border-color: color-mix(in srgb, var(--spark) 55%, var(--border)); background: var(--spark-soft); }
.safety-title { display: flex; align-items: center; gap: 6px; font-weight: 650; font-size: 13px; }
.safety-title svg { width: 16px; height: 16px; }
.safety.danger .safety-title svg { color: var(--err); }
.safety.caution .safety-title svg { color: var(--spark); }
.safety ul { margin: 6px 0 0; padding-left: 18px; }
.safety li { margin: 2px 0; }
.safety-note { margin: 6px 0 0; color: var(--fg-muted); font-size: 11.5px; }
.safety-actions { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; }
.safety-actions button { border: 1px solid var(--border); background: var(--bg); border-radius: 8px; padding: 3px 9px; font-size: 11.5px; font-weight: 550; }
.safety-actions .primary { background: var(--err); border-color: var(--err); color: #fff; }
.safety-actions .quiet { border-color: transparent; background: none; color: var(--fg-muted); }
.progress { height: 4px; border-radius: 4px; background: var(--border); margin-top: 8px; overflow: hidden; }
.progress > div { height: 100%; background: linear-gradient(90deg, var(--brand), var(--spark)); width: 0; transition: width 0.2s ease; }

/* Site toolbar (e.g. X): page label and option toggles */
.site-bar { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; padding: 8px 12px; border-bottom: 1px solid var(--border); background: var(--bg-soft); font-size: 12.5px; }
.site-label { font-weight: 600; margin-right: auto; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 60%; }
.toggle { display: inline-flex; align-items: center; gap: 6px; padding: 3px 9px 3px 4px; border: 1px solid var(--border); border-radius: 999px; background: var(--bg); font-size: 11.5px; font-weight: 500; }
.toggle::before { content: ""; width: 22px; height: 13px; border-radius: 999px; background: var(--border); box-shadow: inset -9px 0 0 2px var(--bg); transition: background 0.15s, box-shadow 0.15s; }
.toggle[aria-pressed="true"] { border-color: var(--accent); }
.toggle[aria-pressed="true"]::before { background: var(--accent); box-shadow: inset 9px 0 0 2px var(--bg); }

/* Research sources */
.sources { margin: 6px 0 0; padding-left: 20px; font-size: 13px; }
.sources li { margin: 3px 0; }
.sources a { color: var(--accent); text-decoration: none; }
.sources a:hover { text-decoration: underline; }
.sources small { color: var(--fg-muted); }

/* Model suggestions */
.recs { display: grid; gap: 6px; margin-top: 8px; }
.rec { display: flex; align-items: center; gap: 8px; padding: 6px 8px; border: 1px solid var(--border); border-radius: 9px; background: var(--bg); }
.rec b { font-size: 12.5px; }
.rec small { display: block; color: var(--fg-muted); font-size: 11.5px; }
.rec button { margin-left: auto; border: 1px solid var(--border); background: var(--bg-soft); border-radius: 7px; padding: 3px 9px; font-size: 11.5px; }
.rec button:hover { border-color: var(--accent); }
.cached { font-size: 12px; color: var(--fg-muted); display: flex; align-items: center; gap: 8px; }
.cached button { border: none; background: none; color: var(--accent); padding: 0; font-size: 12px; text-decoration: underline; }

.composer { display: flex; align-items: flex-end; gap: 8px; padding: 10px 12px 6px; border-top: 1px solid var(--border); }
.composer textarea {
  flex: 1; resize: none; min-height: 38px; max-height: 140px; padding: 8px 12px;
  border: 1px solid var(--border); border-radius: 12px; background: var(--bg-soft); outline: none;
}
.composer textarea:focus { border-color: var(--accent); background: var(--bg); box-shadow: 0 0 0 3px var(--accent-soft); }
.send {
  width: 38px; height: 38px; border-radius: 12px; border: none; display: grid; place-items: center;
  background: var(--accent); color: var(--accent-fg);
}
.send:hover:not(:disabled) { background: var(--accent-strong); }
.send.stop { background: var(--spark); color: #1a1205; }

.foot { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 0 12px 8px; font-size: 11.5px; color: var(--fg-muted); }
.foot .feedback { display: inline-flex; align-items: center; gap: 5px; color: var(--fg-muted); text-decoration: none; font-weight: 600; padding: 2px 8px; border-radius: 999px; }
.foot .feedback svg { width: 13px; height: 13px; color: var(--spark); }
.foot .feedback:hover { color: var(--accent); background: var(--accent-soft); }
.foot-note { opacity: 0.75; }

@keyframes spin { to { transform: rotate(360deg); } }
@keyframes pulse { 50% { opacity: 0.35; } }
@keyframes blink { 0%, 94%, 100% { transform: scaleY(1); } 96% { transform: scaleY(0.08); } }
@keyframes watch { 0%, 100% { transform: translateX(0); } 20% { transform: translateX(-2.5px); } 45% { transform: translateX(3px); } 70% { transform: translate(1px, 1.5px); } }
@keyframes scan { 0%, 100% { transform: translateX(-4px); } 50% { transform: translateX(4px); } }
@keyframes flap-l { from { transform: rotate(8deg); } to { transform: rotate(38deg); } }
@keyframes flap-r { from { transform: rotate(-8deg); } to { transform: rotate(-38deg); } }
@keyframes land { 0% { transform: translateY(-5px) scale(1.06, 0.94); } 45% { transform: translateY(1px) scale(0.94, 1.06); } 75% { transform: translateY(-1px) scale(1.02, 0.98); } 100% { transform: none; } }
@keyframes perk { 0% { transform: rotate(0) scale(1); } 35% { transform: rotate(-9deg) scale(1.08); } 70% { transform: rotate(4deg) scale(1); } 100% { transform: rotate(0) scale(1); } }
@keyframes pop { from { opacity: 0; transform: translateY(8px) scale(0.98); } }
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
}
`;

  // Applied to the page itself (outside the shadow root): site filters such as X's "Verified only".
  soroagent.PAGE_CSS = `
[data-soroagent-filtered] { display: none !important; }
`;
})(globalThis);
