// Settings shared by the background worker, content scripts and extension pages.
(function (root) {
  'use strict';

  const soroagent = (root.soroagent = root.soroagent || {});

  // Firefox exposes promise-based APIs on `browser`; Chrome MV3 returns promises on `chrome`.
  // Check `runtime.id` because a page element with id="browser" also shows up as window.browser.
  const ext =
    root.browser && root.browser.runtime && root.browser.runtime.id ? root.browser : root.chrome;

  const DEFAULT_SETTINGS = Object.freeze({
    source: 'local', // 'local' | 'cloud'

    // Local model server
    baseUrl: 'http://127.0.0.1:11434',
    provider: 'auto', // 'auto' | 'ollama' | 'openai'
    model: '',
    apiKey: '',

    // Cloud provider (API keys are stored encrypted by the background worker, see background/secrets.js)
    cloudProvider: 'anthropic',
    cloudModels: {}, // provider id -> chosen model
    customBaseUrl: '',

    temperature: 0.3,
    contextWindow: 8192, // Ollama num_ctx; its default is too small for whole pages
    maxPageChars: 12000,
    researchEngine: 'auto', // 'auto' | 'duckduckgo' | 'brave' | 'searxng'
    searxUrl: '', // e.g. http://127.0.0.1:8888 for a self-hosted SearXNG
    cleanSites: [], // sites where "Hide ads" is applied automatically
    panelSize: 0, // 0 (default) … 3 (largest), changed with the panel's ++ / -- buttons
    darkSites: {}, // sites shown in dark mode: { [hostname]: { brightness, contrast, sepia } }
    readMoreLimit: 200, // feeds: "Read more" stops for good after this many posts on a page
    allowThinking: false,
    showLauncher: true,
    launcherPosition: 'auto', // 'auto' | 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left'
    launcherPlacements: {}, // hostname -> { side: 'left' | 'right', y: 0..1 } after the user drags the button
    hiddenSites: [],
    siteOptions: {}, // site profile id -> { optionId: value }, e.g. { x: { verifiedOnly: true } }
  });

  const PROVIDER_PRESETS = Object.freeze([
    { id: 'ollama', label: 'Ollama', baseUrl: 'http://127.0.0.1:11434', provider: 'ollama' },
    { id: 'lmstudio', label: 'LM Studio', baseUrl: 'http://127.0.0.1:1234/v1', provider: 'openai' },
    { id: 'llamacpp', label: 'llama.cpp server', baseUrl: 'http://127.0.0.1:8080/v1', provider: 'openai' },
    { id: 'jan', label: 'Jan', baseUrl: 'http://127.0.0.1:1337/v1', provider: 'openai' },
  ]);

  // Hosted APIs. `api` is the wire format; most providers speak the OpenAI chat-completions dialect.
  // `include`/`exclude` trim each provider's model list down to chat models; `prefer` picks the
  // default when the user hasn't chosen one.
  const NON_CHAT = /embed|whisper|tts|audio|realtime|transcribe|image|dall-e|moderation|search|guard|vision-preview|imagen|veo|aqa|computer-use/i;
  const CLOUD_PROVIDERS = Object.freeze([
    {
      id: 'anthropic',
      label: 'Anthropic (Claude)',
      api: 'anthropic',
      baseUrl: 'https://api.anthropic.com/v1',
      keyUrl: 'https://console.anthropic.com/settings/keys',
      keyPlaceholder: 'sk-ant-…',
      include: /^claude-/,
      prefer: [/^claude-opus-5-5$/, /^claude-opus/, /^claude-sonnet/],
    },
    {
      id: 'openai',
      label: 'OpenAI',
      api: 'openai',
      baseUrl: 'https://api.openai.com/v1',
      keyUrl: 'https://platform.openai.com/api-keys',
      keyPlaceholder: 'sk-…',
      include: /^(gpt-|o\d|chatgpt-)/,
      prefer: [/^gpt-5(\.\d+)?$/, /^gpt-5/, /^gpt-4\.1$/, /^gpt-4o$/],
    },
    {
      id: 'gemini',
      label: 'Google Gemini',
      api: 'openai',
      baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
      keyUrl: 'https://aistudio.google.com/apikey',
      keyPlaceholder: 'AIza…',
      include: /^gemini-/,
      prefer: [/^gemini-[\d.]+-pro$/, /^gemini-[\d.]+-flash$/, /pro/, /flash/],
    },
    {
      id: 'openrouter',
      label: 'OpenRouter',
      api: 'openai',
      baseUrl: 'https://openrouter.ai/api/v1',
      keyUrl: 'https://openrouter.ai/keys',
      keyPlaceholder: 'sk-or-…',
      prefer: [/^anthropic\/claude-opus/, /^openai\/gpt-5/, /^google\/gemini/],
    },
    {
      id: 'groq',
      label: 'Groq',
      api: 'openai',
      baseUrl: 'https://api.groq.com/openai/v1',
      keyUrl: 'https://console.groq.com/keys',
      keyPlaceholder: 'gsk_…',
      prefer: [/llama.*70b/, /llama/],
    },
    {
      id: 'mistral',
      label: 'Mistral',
      api: 'openai',
      baseUrl: 'https://api.mistral.ai/v1',
      keyUrl: 'https://console.mistral.ai/api-keys',
      keyPlaceholder: '',
      prefer: [/^mistral-large-latest$/, /^mistral-medium-latest$/, /large/],
    },
    {
      id: 'deepseek',
      label: 'DeepSeek',
      api: 'openai',
      baseUrl: 'https://api.deepseek.com/v1',
      keyUrl: 'https://platform.deepseek.com/api_keys',
      keyPlaceholder: 'sk-…',
      prefer: [/^deepseek-chat$/],
    },
    {
      id: 'xai',
      label: 'xAI (Grok)',
      api: 'openai',
      baseUrl: 'https://api.x.ai/v1',
      keyUrl: 'https://console.x.ai',
      keyPlaceholder: 'xai-…',
      include: /^grok-/,
      prefer: [/^grok-\d+$/, /^grok/],
    },
    {
      id: 'custom',
      label: 'Other (OpenAI-compatible URL)',
      api: 'openai',
      baseUrl: '', // from settings.customBaseUrl
      keyUrl: '',
      keyPlaceholder: '',
    },
  ]);

  function cloudProvider(id) {
    return CLOUD_PROVIDERS.find((p) => p.id === id) || CLOUD_PROVIDERS[0];
  }

  /**
   * Describes where requests go for the current settings. Everything that talks to a model
   * works from this object, so local and cloud share one code path.
   */
  function resolveConnection(settings, apiKeys = {}) {
    const generation = {
      temperature: Number(settings.temperature),
      contextWindow: Number(settings.contextWindow) || 8192,
      allowThinking: Boolean(settings.allowThinking),
    };
    if (settings.source === 'cloud') {
      const p = cloudProvider(settings.cloudProvider);
      return {
        id: p.id,
        label: p.id === 'custom' ? 'Custom API' : p.label.replace(/ \(.*\)$/, ''),
        cloud: true,
        api: p.api,
        baseUrl: p.id === 'custom' ? String(settings.customBaseUrl || '').trim().replace(/\/+$/, '') : p.baseUrl,
        apiKey: apiKeys[p.id] || '',
        model: (settings.cloudModels || {})[p.id] || '',
        catalog: p,
        ...generation,
      };
    }
    return {
      id: 'local',
      label: 'Local',
      cloud: false,
      api: settings.provider || 'auto',
      baseUrl: settings.baseUrl,
      apiKey: settings.apiKey || '',
      model: settings.model || '',
      catalog: null,
      ...generation,
    };
  }

  // Settings patch that stores `model` as the choice for whichever connection is active.
  function modelPatch(settings, model) {
    if (settings.source !== 'cloud') return { model };
    return { cloudModels: { ...(settings.cloudModels || {}), [settings.cloudProvider]: model } };
  }

  async function getSettings() {
    const stored = await ext.storage.local.get('settings');
    return { ...DEFAULT_SETTINGS, ...(stored.settings || {}) };
  }

  async function saveSettings(patch) {
    const next = { ...(await getSettings()), ...patch };
    await ext.storage.local.set({ settings: next });
    return next;
  }

  // Extension pages report the browser theme so the toolbar icon can match it.
  if (root.document && root.location && /^(chrome|moz)-extension:$/.test(root.location.protocol) && root.matchMedia) {
    const query = root.matchMedia('(prefers-color-scheme: dark)');
    const report = () => ext.runtime.sendMessage({ type: 'theme', dark: query.matches }).catch(() => {});
    query.addEventListener('change', report);
    report();
  }

  Object.assign(soroagent, {
    ext,
    DEFAULT_SETTINGS,
    PROVIDER_PRESETS,
    CLOUD_PROVIDERS,
    NON_CHAT,
    cloudProvider,
    resolveConnection,
    modelPatch,
    getSettings,
    saveSettings,
  });
})(globalThis);
